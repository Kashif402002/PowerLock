plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.kashif.powerlock"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.kashif.powerlock"
        minSdk = 26
        targetSdk = 34
        versionCode = 3
        versionName = "1.2"
    }
    signingConfigs {
        getByName("debug") {
            storeFile = file("powerlock.keystore")
            storePassword = "powerlock"
            keyAlias = "powerlock"
            keyPassword = "powerlock"
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

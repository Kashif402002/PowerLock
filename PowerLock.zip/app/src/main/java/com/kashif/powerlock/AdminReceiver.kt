package com.kashif.powerlock

import android.app.admin.DeviceAdminReceiver
import android.content.Context
import android.content.Intent

/** Active device admins can't be uninstalled until the admin is switched off first. */
class AdminReceiver : DeviceAdminReceiver() {
    override fun onDisableRequested(context: Context, intent: Intent): CharSequence? =
        if (LockStore.guardActive(context))
            "Power Lock is protecting your phone right now. Turning this off is blocked while a lock or schedule is on."
        else null
}

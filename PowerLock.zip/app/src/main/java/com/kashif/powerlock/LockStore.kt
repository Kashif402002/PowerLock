package com.kashif.powerlock

import android.content.Context
import android.os.SystemClock
import android.provider.Settings
import java.util.Calendar

/**
 * Manual locks use the monotonic clock (elapsedRealtime), so changing the date/time cannot
 * shorten them. Scheduled locks follow the wall clock (guarded by blocking date/time settings).
 */
object LockStore {
    data class Status(val remainingMs: Long, val totalMs: Long, val scheduled: Boolean)

    private fun prefs(c: Context) = c.getSharedPreferences("lock", Context.MODE_PRIVATE)

    private fun bootCount(c: Context): Int =
        Settings.Global.getInt(c.contentResolver, Settings.Global.BOOT_COUNT, -1)

    // ---------- manual lock ----------
    private fun manualTotalMs(c: Context): Long = prefs(c).getLong("total", 0L)

    private fun manualRemainingMs(c: Context): Long {
        val p = prefs(c)
        val endWall = p.getLong("endWall", 0L)
        if (endWall == 0L) return 0L
        var endElapsed = p.getLong("endElapsed", 0L)
        val boot = bootCount(c)
        if (p.getInt("boot", -1) != boot) {
            val rem = maxOf(0L, endWall - System.currentTimeMillis())
            endElapsed = SystemClock.elapsedRealtime() + rem
            p.edit().putLong("endElapsed", endElapsed).putInt("boot", boot).commit()
        }
        return maxOf(0L, endElapsed - SystemClock.elapsedRealtime())
    }

    // Only allows starting a new lock; an active lock can never be shortened or cancelled.
    fun startManual(c: Context, durationMs: Long) {
        if (manualRemainingMs(c) > 0L) return
        prefs(c).edit()
            .putLong("endWall", System.currentTimeMillis() + durationMs)
            .putLong("endElapsed", SystemClock.elapsedRealtime() + durationMs)
            .putLong("total", durationMs)
            .putInt("boot", bootCount(c))
            .commit()
    }

    // ---------- daily schedule ----------
    fun scheduleEnabled(c: Context): Boolean = prefs(c).getBoolean("sEnabled", false)
    fun scheduleStart(c: Context): Int = prefs(c).getInt("sStart", 23 * 60)
    fun scheduleEnd(c: Context): Int = prefs(c).getInt("sEnd", 6 * 60)
    // bit n set = Calendar day-of-week n is on (1 = Sunday ... 7 = Saturday)
    fun scheduleDays(c: Context): Int = prefs(c).getInt("sDays", 0xFE)

    fun setSchedule(c: Context, enabled: Boolean, start: Int, end: Int, days: Int) {
        prefs(c).edit()
            .putBoolean("sEnabled", enabled)
            .putInt("sStart", start)
            .putInt("sEnd", end)
            .putInt("sDays", days)
            .commit()
    }

    /** Returns [remainingMs, totalMs] if a scheduled window is active right now, else null. */
    private fun scheduleState(c: Context): LongArray? {
        if (!scheduleEnabled(c)) return null
        val s = scheduleStart(c) * 60
        val e = scheduleEnd(c) * 60
        if (s == e) return null
        val cal = Calendar.getInstance()
        val nowSec = cal.get(Calendar.HOUR_OF_DAY) * 3600 + cal.get(Calendar.MINUTE) * 60 + cal.get(Calendar.SECOND)
        val dow = cal.get(Calendar.DAY_OF_WEEK)
        val yesterday = if (dow == 1) 7 else dow - 1
        val days = scheduleDays(c)
        fun on(d: Int): Boolean = (days and (1 shl d)) != 0

        val rem: Int
        val total: Int
        if (s < e) {
            if (!on(dow) || nowSec < s || nowSec >= e) return null
            rem = e - nowSec
            total = e - s
        } else {
            total = 86400 - s + e
            if (on(dow) && nowSec >= s) {
                rem = 86400 - nowSec + e
            } else if (on(yesterday) && nowSec < e) {
                rem = e - nowSec
            } else {
                return null
            }
        }
        return longArrayOf(rem * 1000L, total * 1000L)
    }

    // ---------- combined ----------
    fun status(c: Context): Status {
        val m = manualRemainingMs(c)
        val sch = scheduleState(c)
        val sr = sch?.get(0) ?: 0L
        return when {
            m == 0L && sr == 0L -> Status(0L, 0L, false)
            m >= sr -> Status(m, manualTotalMs(c), false)
            else -> Status(sr, sch!![1], true)
        }
    }

    fun isLocked(c: Context): Boolean = status(c).remainingMs > 0L

    /** Settings/uninstall/date-time guards stay on whenever a lock is active or a schedule is set. */
    fun guardActive(c: Context): Boolean = isLocked(c) || scheduleEnabled(c)
}

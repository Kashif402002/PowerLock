package com.kashif.powerlock

import android.content.Context

object LockStore {
    private fun prefs(c: Context) = c.getSharedPreferences("lock", Context.MODE_PRIVATE)

    fun endTime(c: Context): Long = prefs(c).getLong("end", 0L)
    fun isLocked(c: Context): Boolean = System.currentTimeMillis() < endTime(c)

    // Only allows starting a new lock; an active lock can never be shortened or cancelled.
    fun start(c: Context, durationMs: Long) {
        if (isLocked(c)) return
        prefs(c).edit().putLong("end", System.currentTimeMillis() + durationMs).commit()
    }
}

package com.kashif.powerlock

import android.content.Context
import android.os.SystemClock
import android.provider.Settings

/**
 * Lock timing uses the phone's monotonic clock (elapsedRealtime), so changing the
 * date/time cannot shorten a lock. After a reboot the monotonic clock resets, so the
 * remaining time is re-anchored once from the wall clock.
 */
object LockStore {
    private fun prefs(c: Context) = c.getSharedPreferences("lock", Context.MODE_PRIVATE)

    private fun bootCount(c: Context): Int =
        Settings.Global.getInt(c.contentResolver, Settings.Global.BOOT_COUNT, -1)

    fun totalMs(c: Context): Long = prefs(c).getLong("total", 0L)

    fun remainingMs(c: Context): Long {
        val p = prefs(c)
        val endWall = p.getLong("endWall", 0L)
        if (endWall == 0L) return 0L
        var endElapsed = p.getLong("endElapsed", 0L)
        val boot = bootCount(c)
        if (p.getInt("boot", -1) != boot) {
            val rem = maxOf(0L, endWall - System.currentTimeMillis())
            endElapsed = SystemClock.elapsedRealtime() + rem
            p.edit().putLong("endElapsed", endElapsed).putInt("boot", boot).commit()
        }
        return maxOf(0L, endElapsed - SystemClock.elapsedRealtime())
    }

    fun isLocked(c: Context): Boolean = remainingMs(c) > 0L

    // Only allows starting a new lock; an active lock can never be shortened or cancelled.
    fun start(c: Context, durationMs: Long) {
        if (isLocked(c)) return
        prefs(c).edit()
            .putLong("endWall", System.currentTimeMillis() + durationMs)
            .putLong("endElapsed", SystemClock.elapsedRealtime() + durationMs)
            .putLong("total", durationMs)
            .putInt("boot", bootCount(c))
            .commit()
    }
}

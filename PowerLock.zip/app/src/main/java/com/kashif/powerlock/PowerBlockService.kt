package com.kashif.powerlock

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class PowerBlockService : AccessibilityService() {

    private var lastAction = 0L

    private val powerWords = listOf(
        "power off", "restart", "shut down", "shutdown", "reboot", "switch off", "power down"
    )

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e == null || !LockStore.isLocked(this)) return
        val pkg = e.packageName?.toString() ?: return
        val now = System.currentTimeMillis()
        if (now - lastAction < 400) return

        val root = rootInActiveWindow

        // 1) Power menu (shown by System UI on most phones)
        if ((pkg == "com.android.systemui" || pkg == "android") &&
            e.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
        ) {
            val cls = e.className?.toString()?.lowercase() ?: ""
            val looksLikePowerMenu = cls.contains("globalactions") ||
                cls.contains("powermenu") || cls.contains("shutdown") ||
                hasText(root, powerWords, 0)
            if (looksLikePowerMenu) {
                lastAction = now
                performGlobalAction(GLOBAL_ACTION_BACK)
                performGlobalAction(GLOBAL_ACTION_HOME)
            }
            return
        }

        // 2) Stop the user from turning this service off in Settings while locked
        if (pkg == "com.android.settings" || pkg.contains("packageinstaller")) {
            if (hasText(root, listOf("power lock"), 0)) {
                lastAction = now
                performGlobalAction(GLOBAL_ACTION_HOME)
            }
        }
    }

    private fun hasText(n: AccessibilityNodeInfo?, words: List<String>, depth: Int): Boolean {
        if (n == null || depth > 12) return false
        val t = (n.text?.toString() ?: "") + " " + (n.contentDescription?.toString() ?: "")
        val lower = t.lowercase()
        if (words.any { lower.contains(it) }) return true
        for (i in 0 until n.childCount) {
            if (hasText(n.getChild(i), words, depth + 1)) return true
        }
        return false
    }

    override fun onInterrupt() {}
}

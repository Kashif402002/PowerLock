package com.kashif.powerlock

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class PowerBlockService : AccessibilityService() {

    private var lastAction = 0L

    private val powerWords = listOf(
        "power off", "restart", "shut down", "shutdown", "reboot", "switch off", "power down"
    )
    private val timeWords = listOf(
        "use network-provided time", "set time automatically", "automatic date",
        "set date", "set time", "date & time settings"
    )
    private val assistants = listOf(
        "com.google.android.googlequicksearchbox",
        "com.google.android.apps.assistant",
        "com.samsung.android.bixby.agent",
        "com.samsung.android.bixby.service"
    )

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e == null) return
        val pkg = e.packageName?.toString() ?: return
        if (!LockStore.guardActive(this)) return
        val locked = LockStore.isLocked(this)
        val now = System.currentTimeMillis()
        if (now - lastAction < 400) return

        val root = rootInActiveWindow
        val cls = e.className?.toString()?.lowercase() ?: ""

        // 1) Power menu (only while a lock is active)
        if (locked && (pkg == "com.android.systemui" || pkg == "android") &&
            e.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
        ) {
            if (cls.contains("globalactions") || cls.contains("powermenu") ||
                cls.contains("shutdown") || hasText(root, powerWords)
            ) kickOut(now)
            return
        }

        // 2) Voice assistant shutdown (only while a lock is active)
        if (locked && pkg in assistants && e.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            if (hasText(root, powerWords)) kickOut(now)
            return
        }

        // 3) Guards: this app's own Settings/uninstall screens + date/time pages
        if (pkg.contains("settings") || pkg.contains("packageinstaller")) {
            if (cls.contains("datetime") ||
                hasText(root, timeWords) ||
                hasText(root, listOf("power lock"))
            ) kickOut(now)
            return
        }

        // 4) Uninstalling from the Play Store
        if (pkg == "com.android.vending" &&
            hasText(root, listOf("power lock")) && hasText(root, listOf("uninstall"))
        ) kickOut(now)
    }

    private fun kickOut(now: Long) {
        lastAction = now
        performGlobalAction(GLOBAL_ACTION_BACK)
        performGlobalAction(GLOBAL_ACTION_HOME)
    }

    private fun hasText(n: AccessibilityNodeInfo?, words: List<String>, depth: Int = 0): Boolean {
        if (n == null || depth > 12) return false
        val t = (n.text?.toString() ?: "") + " " + (n.contentDescription?.toString() ?: "")
        val lower = t.lowercase()
        if (words.any { lower.contains(it) }) return true
        for (i in 0 until n.childCount) {
            if (hasText(n.getChild(i), words, depth + 1)) return true
        }
        return false
    }

    override fun onInterrupt() {}
}

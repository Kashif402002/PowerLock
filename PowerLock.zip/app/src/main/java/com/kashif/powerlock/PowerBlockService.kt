package com.kashif.powerlock

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class PowerBlockService : AccessibilityService() {

    private var lastAction = 0L

    private val powerWords = listOf(
        "power off", "restart", "shut down", "shutdown", "reboot", "switch off", "power down"
    )
    private val timeWords = listOf(
        "use network-provided time", "set time automatically", "automatic date",
        "set date", "set time", "date & time settings"
    )
    private val assistants = listOf(
        "com.google.android.googlequicksearchbox",
        "com.google.android.apps.assistant",
        "com.samsung.android.bixby.agent",
        "com.samsung.android.bixby.service"
    )

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e == null || !LockStore.isLocked(this)) return
        val pkg = e.packageName?.toString() ?: return
        val now = System.currentTimeMillis()
        if (now - lastAction < 400) return

        val root = rootInActiveWindow
        val cls = e.className?.toString()?.lowercase() ?: ""

        // 1) Power menu (System UI)
        if ((pkg == "com.android.systemui" || pkg == "android") &&
            e.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
        ) {
            if (cls.contains("globalactions") || cls.contains("powermenu") ||
                cls.contains("shutdown") || hasText(root, powerWords)
            ) kickOut(now)
            return
        }

        // 2) Voice assistant shutdown ("turn off the phone")
        if (pkg in assistants && e.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            if (hasText(root, powerWords)) kickOut(now)
            return
        }

        // 3) Settings guard: this app's own entry + date/time pages
        if (pkg == "com.android.settings" || pkg.contains("packageinstaller")) {
            if (cls.contains("datetime") ||
                hasText(root, timeWords) ||
                hasText(root, listOf("power lock"))
            ) kickOut(now)
        }
    }

    private fun kickOut(now: Long) {
        lastAction = now
        performGlobalAction(GLOBAL_ACTION_BACK)
        performGlobalAction(GLOBAL_ACTION_HOME)
    }

    private fun hasText(n: AccessibilityNodeInfo?, words: List<String>, depth: Int = 0): Boolean {
        if (n == null || depth > 12) return false
        val t = (n.text?.toString() ?: "") + " " + (n.contentDescription?.toString() ?: "")
        val lower = t.lowercase()
        if (words.any { lower.contains(it) }) return true
        for (i in 0 until n.childCount) {
            if (hasText(n.getChild(i), words, depth + 1)) return true
        }
        return false
    }

    override fun onInterrupt() {}
}

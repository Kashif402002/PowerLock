package com.kashif.powerlock

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {

    private val bg = Color.parseColor("#0F0D2E")
    private val card = Color.parseColor("#1B1846")
    private val chipOff = Color.parseColor("#2C2860")
    private val accent = Color.parseColor("#6C63FF")
    private val good = Color.parseColor("#34D399")
    private val warn = Color.parseColor("#FBBF24")
    private val muted = Color.parseColor("#9CA3AF")

    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var stateLabel: TextView
    private lateinit var timer: TextView
    private lateinit var sub: TextView
    private lateinit var progress: ProgressBar
    private lateinit var startBtn: Button
    private lateinit var accBtn: Button
    private val chips = mutableListOf<TextView>()
    private val checks = mutableListOf<TextView>()
    private val checkLabels = listOf(
        "Power menu blocked",
        "Voice assistant shutdown blocked",
        "Clock-change protection",
        "Date & time settings blocked",
        "Accessibility settings guarded"
    )
    private val hoursOptions = listOf(1, 2, 4, 8, 12, 24)
    private var selected = 8

    private val tick = object : Runnable {
        override fun run() {
            refresh()
            handler.postDelayed(this, 1000)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun round(color: Int, radiusDp: Int, stroke: Int? = null) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radiusDp).toFloat()
        if (stroke != null) setStroke(dp(2), stroke)
    }

    private fun tv(t: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = t
        textSize = size
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun lp(top: Int = 0, bottom: Int = 0) =
        LinearLayout.LayoutParams(MATCH, WRAP).apply { setMargins(0, dp(top), 0, dp(bottom)) }

    private fun cardBox() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = round(card, 24)
        setPadding(dp(20), dp(20), dp(20), dp(20))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg

        val scroll = ScrollView(this).apply { setBackgroundColor(bg); isFillViewport = true }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(44), dp(20), dp(28))
        }
        scroll.addView(root, ViewGroup.LayoutParams(MATCH, WRAP))

        root.addView(tv("Power Lock", 30f, Color.WHITE, true), lp())
        root.addView(tv("Block power off & restart while you stay focused", 14f, muted), lp(2, 20))

        // Status card
        val status = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            background = round(card, 28)
            setPadding(dp(20), dp(28), dp(20), dp(24))
        }
        stateLabel = tv("READY", 13f, good, true).apply { letterSpacing = 0.15f }
        timer = tv("--:--:--", 46f, Color.WHITE, true).apply {
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        }
        sub = tv("", 14f, muted).apply { gravity = Gravity.CENTER }
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 1000
            progressTintList = ColorStateList.valueOf(accent)
            progressBackgroundTintList = ColorStateList.valueOf(chipOff)
        }
        status.addView(stateLabel, LinearLayout.LayoutParams(WRAP, WRAP))
        status.addView(timer, LinearLayout.LayoutParams(WRAP, WRAP).apply { setMargins(0, dp(8), 0, dp(8)) })
        status.addView(progress, LinearLayout.LayoutParams(MATCH, dp(8)).apply { setMargins(0, dp(4), 0, dp(12)) })
        status.addView(sub, LinearLayout.LayoutParams(WRAP, WRAP))
        root.addView(status, lp(0, 16))

        // Duration card
        val durCard = cardBox()
        durCard.addView(tv("Lock duration", 15f, Color.WHITE, true), lp(0, 12))
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        hoursOptions.forEach { h ->
            val c = tv("${h}h", 15f, Color.WHITE, true).apply {
                gravity = Gravity.CENTER
                setPadding(0, dp(14), 0, dp(14))
                setOnClickListener {
                    if (!LockStore.isLocked(this@MainActivity)) {
                        selected = h
                        styleChips()
                        refresh()
                    }
                }
            }
            chips.add(c)
            row.addView(c, LinearLayout.LayoutParams(0, WRAP, 1f).apply { setMargins(dp(3), 0, dp(3), 0) })
        }
        durCard.addView(row, lp())
        root.addView(durCard, lp(0, 16))

        // Buttons
        startBtn = Button(this).apply {
            text = "Start lock"
            isAllCaps = false
            textSize = 17f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            background = round(accent, 16)
            stateListAnimator = null
            setOnClickListener { confirmStart() }
        }
        root.addView(startBtn, LinearLayout.LayoutParams(MATCH, dp(56)).apply { setMargins(0, 0, 0, dp(10)) })

        accBtn = Button(this).apply {
            text = "Enable Accessibility service"
            isAllCaps = false
            textSize = 15f
            setTextColor(Color.WHITE)
            background = round(Color.TRANSPARENT, 16, accent)
            stateListAnimator = null
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        root.addView(accBtn, LinearLayout.LayoutParams(MATCH, dp(52)).apply { setMargins(0, 0, 0, dp(16)) })

        // Protection card
        val prot = cardBox()
        prot.addView(tv("Protection", 15f, Color.WHITE, true), lp(0, 10))
        checkLabels.forEach {
            val t = tv(it, 14f, muted)
            checks.add(t)
            prot.addView(t, lp(4, 4))
        }
        root.addView(prot, lp(0, 12))

        root.addView(
            tv("A forced restart (holding Power + Volume Up for ~10 seconds) can't be blocked by any app.", 12f, muted),
            lp()
        )

        setContentView(scroll)
        styleChips()
    }

    override fun onResume() { super.onResume(); handler.post(tick) }
    override fun onPause() { super.onPause(); handler.removeCallbacks(tick) }

    private fun styleChips() {
        chips.forEachIndexed { i, c ->
            val sel = hoursOptions[i] == selected
            c.background = round(if (sel) accent else chipOff, 14)
            c.setTextColor(if (sel) Color.WHITE else muted)
        }
    }

    private fun serviceEnabled(): Boolean {
        val enabled = Settings.Secure.getString(
            contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return enabled.contains("$packageName/") && enabled.contains("PowerBlockService")
    }

    private fun confirmStart() {
        val hours = selected
        AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle("Start $hours hour lock?")
            .setMessage("This cannot be cancelled. Power off and restart will be blocked until it ends.")
            .setPositiveButton("Lock") { _, _ ->
                LockStore.start(this, hours * 3600_000L)
                refresh()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun fmt(ms: Long): String {
        val s = ms / 1000
        return "%02d:%02d:%02d".format(s / 3600, (s % 3600) / 60, s % 60)
    }

    private fun refresh() {
        val rem = LockStore.remainingMs(this)
        val locked = rem > 0L
        val enabled = serviceEnabled()

        when {
            locked -> {
                stateLabel.text = "LOCKED"
                stateLabel.setTextColor(warn)
                timer.text = fmt(rem)
                sub.text = "Power off & restart are blocked"
                val total = LockStore.totalMs(this)
                progress.progress =
                    if (total > 0) ((1.0 - rem.toDouble() / total) * 1000).toInt().coerceIn(0, 1000) else 0
            }
            !enabled -> {
                stateLabel.text = "SETUP NEEDED"
                stateLabel.setTextColor(warn)
                timer.text = "--:--:--"
                sub.text = "Enable the Accessibility service to begin"
                progress.progress = 0
            }
            else -> {
                stateLabel.text = "READY"
                stateLabel.setTextColor(good)
                timer.text = fmt(selected * 3600_000L)
                sub.text = "Pick a duration and start"
                progress.progress = 0
            }
        }

        startBtn.isEnabled = !locked && enabled
        startBtn.alpha = if (startBtn.isEnabled) 1f else 0.4f
        accBtn.visibility = if (enabled) View.GONE else View.VISIBLE
        chips.forEach { it.alpha = if (locked) 0.4f else 1f }

        checks.forEachIndexed { i, t ->
            t.text = (if (enabled) "✓  " else "○  ") + checkLabels[i]
            t.setTextColor(if (enabled) good else muted)
        }
    }
}

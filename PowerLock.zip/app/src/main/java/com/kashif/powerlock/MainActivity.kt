package com.kashif.powerlock

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.NumberPicker
import android.widget.TextView

class MainActivity : Activity() {

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var status: TextView
    private lateinit var picker: NumberPicker
    private lateinit var startBtn: Button
    private lateinit var accBtn: Button

    private val tick = object : Runnable {
        override fun run() {
            refresh()
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(48, 120, 48, 48)
        }

        root.addView(TextView(this).apply {
            text = "Power Lock"
            textSize = 28f
            gravity = Gravity.CENTER
        })

        status = TextView(this).apply {
            textSize = 18f
            gravity = Gravity.CENTER
            setPadding(0, 48, 0, 48)
        }
        root.addView(status)

        root.addView(TextView(this).apply { text = "Lock for (hours)"; gravity = Gravity.CENTER })
        picker = NumberPicker(this).apply { minValue = 1; maxValue = 24; value = 8 }
        root.addView(picker)

        startBtn = Button(this).apply {
            text = "Start lock"
            setOnClickListener { confirmStart() }
        }
        root.addView(startBtn)

        accBtn = Button(this).apply {
            text = "Enable Accessibility service"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        root.addView(accBtn)

        setContentView(root)
    }

    override fun onResume() { super.onResume(); handler.post(tick) }
    override fun onPause() { super.onPause(); handler.removeCallbacks(tick) }

    private fun serviceEnabled(): Boolean {
        val enabled = Settings.Secure.getString(
            contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return enabled.contains("$packageName/") && enabled.contains("PowerBlockService")
    }

    private fun confirmStart() {
        val hours = picker.value
        AlertDialog.Builder(this)
            .setTitle("Start $hours hour lock?")
            .setMessage("This cannot be cancelled. Power off and restart will be blocked until it ends.")
            .setPositiveButton("Lock") { _, _ ->
                LockStore.start(this, hours * 3600_000L)
                refresh()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun refresh() {
        val locked = LockStore.isLocked(this)
        val enabled = serviceEnabled()
        accBtn.isEnabled = !locked
        accBtn.visibility = if (enabled) android.view.View.GONE else android.view.View.VISIBLE
        picker.isEnabled = !locked && enabled
        startBtn.isEnabled = !locked && enabled
        status.text = when {
            locked -> {
                val s = (LockStore.endTime(this) - System.currentTimeMillis()) / 1000
                "LOCKED\n%02d:%02d:%02d left".format(s / 3600, (s % 3600) / 60, s % 60)
            }
            !enabled -> "Step 1: enable the Accessibility service"
            else -> "Ready. Pick a duration and start."
        }
    }
}

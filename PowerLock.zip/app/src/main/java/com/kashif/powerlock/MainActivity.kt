package com.kashif.powerlock

import android.app.Activity
import android.app.AlertDialog
import android.app.TimePickerDialog
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.NumberPicker
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private val bg = Color.parseColor("#0F0D2E")
    private val card = Color.parseColor("#1B1846")
    private val chipOff = Color.parseColor("#2C2860")
    private val accent = Color.parseColor("#6C63FF")
    private val good = Color.parseColor("#34D399")
    private val warn = Color.parseColor("#FBBF24")
    private val muted = Color.parseColor("#9CA3AF")

    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private val handler = Handler(Looper.getMainLooper())

    private lateinit var stateLabel: TextView
    private lateinit var timer: TextView
    private lateinit var sub: TextView
    private lateinit var progress: ProgressBar
    private lateinit var startBtn: Button
    private lateinit var accBtn: Button
    private lateinit var adminBtn: Button
    private lateinit var hPick: NumberPicker
    private lateinit var mPick: NumberPicker
    private lateinit var schedSwitch: Switch
    private lateinit var fromBtn: Button
    private lateinit var toBtn: Button
    private lateinit var schedSummary: TextView
    private lateinit var durRow: LinearLayout
    private lateinit var dayRow: LinearLayout

    private val chips = mutableListOf<TextView>()
    private val dayChips = mutableListOf<TextView>()
    private val checks = mutableListOf<TextView>()
    private var updatingUi = false

    private val presets = listOf("15m" to 15, "30m" to 30, "1h" to 60, "2h" to 120, "4h" to 240, "8h" to 480)
    private val dayLabels = listOf("M", "T", "W", "T", "F", "S", "S")
    private val dayNames = listOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")
    private val dayCal = listOf(2, 3, 4, 5, 6, 7, 1) // Calendar day numbers for Mon..Sun

    private val checkLabels = listOf(
        "Power menu blocked",
        "Voice assistant shutdown blocked",
        "Clock-change protection",
        "Date & time settings blocked",
        "Accessibility settings guarded",
        "Uninstall protection"
    )

    private val tick = object : Runnable {
        override fun run() {
            refresh()
            handler.postDelayed(this, 1000)
        }
    }

    // ---------- small helpers ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun round(color: Int, radiusDp: Int, stroke: Int? = null) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radiusDp).toFloat()
        if (stroke != null) setStroke(dp(2), stroke)
    }

    private fun tv(t: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = t
        textSize = size
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun lp(top: Int = 0, bottom: Int = 0) =
        LinearLayout.LayoutParams(MATCH, WRAP).apply { setMargins(0, dp(top), 0, dp(bottom)) }

    private fun cardBox() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = round(card, 24)
        setPadding(dp(20), dp(20), dp(20), dp(20))
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    private fun fmtClock(ms: Long): String {
        val s = ms / 1000
        return "%02d:%02d:%02d".format(s / 3600, (s % 3600) / 60, s % 60)
    }

    private fun fmtDur(min: Int): String {
        val h = min / 60
        val m = min % 60
        return when {
            h > 0 && m > 0 -> "${h}h ${m}m"
            h > 0 -> "${h}h"
            else -> "${m}m"
        }
    }

    private fun fmtTime(minOfDay: Int): String {
        val h = minOfDay / 60
        val m = minOfDay % 60
        val ampm = if (h < 12) "AM" else "PM"
        val h12 = if (h % 12 == 0) 12 else h % 12
        return "%d:%02d %s".format(h12, m, ampm)
    }

    private fun totalMinutes() = hPick.value * 60 + mPick.value

    // ---------- UI ----------
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg

        val scroll = ScrollView(this).apply { setBackgroundColor(bg); isFillViewport = true }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(44), dp(20), dp(28))
        }
        scroll.addView(root, ViewGroup.LayoutParams(MATCH, WRAP))

        root.addView(tv("Power Lock", 30f, Color.WHITE, true), lp())
        root.addView(tv("Block power off & restart while you stay focused", 14f, muted), lp(2, 20))

        // ----- Status card -----
        val status = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            background = round(card, 28)
            setPadding(dp(20), dp(28), dp(20), dp(24))
        }
        stateLabel = tv("READY", 13f, good, true).apply { letterSpacing = 0.15f }
        timer = tv("--:--:--", 46f, Color.WHITE, true).apply {
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        }
        sub = tv("", 14f, muted).apply { gravity = Gravity.CENTER }
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 1000
            progressTintList = ColorStateList.valueOf(accent)
            progressBackgroundTintList = ColorStateList.valueOf(chipOff)
        }
        status.addView(stateLabel, LinearLayout.LayoutParams(WRAP, WRAP))
        status.addView(timer, LinearLayout.LayoutParams(WRAP, WRAP).apply { setMargins(0, dp(8), 0, dp(8)) })
        status.addView(progress, LinearLayout.LayoutParams(MATCH, dp(8)).apply { setMargins(0, dp(4), 0, dp(12)) })
        status.addView(sub, LinearLayout.LayoutParams(WRAP, WRAP))
        root.addView(status, lp(0, 16))

        // ----- Quick lock card -----
        val durCard = cardBox()
        durCard.addView(tv("Lock now", 15f, Color.WHITE, true), lp(0, 12))

        durRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        presets.forEach { (label, minutes) ->
            val c = tv(label, 14f, Color.WHITE, true).apply {
                gravity = Gravity.CENTER
                setPadding(0, dp(12), 0, dp(12))
                setOnClickListener {
                    if (!LockStore.isLocked(this@MainActivity)) {
                        hPick.value = minutes / 60
                        mPick.value = minutes % 60
                        styleChips()
                        refresh()
                    }
                }
            }
            chips.add(c)
            durRow.addView(c, LinearLayout.LayoutParams(0, WRAP, 1f).apply { setMargins(dp(2), 0, dp(2), 0) })
        }
        durCard.addView(durRow, lp(0, 12))

        val pickRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        hPick = NumberPicker(this).apply { minValue = 0; maxValue = 24; value = 1 }
        mPick = NumberPicker(this).apply { minValue = 0; maxValue = 59; value = 0 }
        val changed = NumberPicker.OnValueChangeListener { _, _, _ -> styleChips(); refresh() }
        hPick.setOnValueChangedListener(changed)
        mPick.setOnValueChangedListener(changed)
        pickRow.addView(hPick, LinearLayout.LayoutParams(WRAP, WRAP))
        pickRow.addView(tv("hours", 14f, muted), LinearLayout.LayoutParams(WRAP, WRAP).apply { setMargins(dp(8), 0, dp(28), 0) })
        pickRow.addView(mPick, LinearLayout.LayoutParams(WRAP, WRAP))
        pickRow.addView(tv("min", 14f, muted), LinearLayout.LayoutParams(WRAP, WRAP).apply { setMargins(dp(8), 0, 0, 0) })
        durCard.addView(pickRow, lp())
        root.addView(durCard, lp(0, 12))

        startBtn = Button(this).apply {
            text = "Start lock"
            isAllCaps = false
            textSize = 17f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            background = round(accent, 16)
            stateListAnimator = null
            setOnClickListener { confirmStart() }
        }
        root.addView(startBtn, LinearLayout.LayoutParams(MATCH, dp(56)).apply { setMargins(0, 0, 0, dp(10)) })

        accBtn = Button(this).apply {
            text = "Enable Accessibility service"
            isAllCaps = false
            textSize = 15f
            setTextColor(Color.WHITE)
            background = round(Color.TRANSPARENT, 16, accent)
            stateListAnimator = null
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        root.addView(accBtn, LinearLayout.LayoutParams(MATCH, dp(52)).apply { setMargins(0, 0, 0, dp(16)) })

        // ----- Schedule card -----
        val schedCard = cardBox()
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        head.addView(tv("Daily schedule", 15f, Color.WHITE, true), LinearLayout.LayoutParams(0, WRAP, 1f))
        schedSwitch = Switch(this).apply {
            setOnCheckedChangeListener { _, checked -> onScheduleToggle(checked) }
        }
        head.addView(schedSwitch, LinearLayout.LayoutParams(WRAP, WRAP))
        schedCard.addView(head, lp(0, 12))

        val timeRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fromBtn = Button(this).apply {
            isAllCaps = false
            textSize = 14f
            setTextColor(Color.WHITE)
            background = round(chipOff, 14)
            stateListAnimator = null
            setOnClickListener { pickTime(true) }
        }
        toBtn = Button(this).apply {
            isAllCaps = false
            textSize = 14f
            setTextColor(Color.WHITE)
            background = round(chipOff, 14)
            stateListAnimator = null
            setOnClickListener { pickTime(false) }
        }
        timeRow.addView(fromBtn, LinearLayout.LayoutParams(0, dp(48), 1f).apply { setMargins(0, 0, dp(6), 0) })
        timeRow.addView(toBtn, LinearLayout.LayoutParams(0, dp(48), 1f).apply { setMargins(dp(6), 0, 0, 0) })
        schedCard.addView(timeRow, lp(0, 12))

        dayRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        dayLabels.forEachIndexed { i, label ->
            val d = tv(label, 14f, Color.WHITE, true).apply {
                gravity = Gravity.CENTER
                setPadding(0, dp(12), 0, dp(12))
                setOnClickListener { toggleDay(dayCal[i]) }
            }
            dayChips.add(d)
            dayRow.addView(d, LinearLayout.LayoutParams(0, WRAP, 1f).apply { setMargins(dp(2), 0, dp(2), 0) })
        }
        schedCard.addView(dayRow, lp(0, 10))

        schedSummary = tv("", 13f, muted)
        schedCard.addView(schedSummary, lp())
        root.addView(schedCard, lp(0, 16))

        // ----- Protection card -----
        val prot = cardBox()
        prot.addView(tv("Protection", 15f, Color.WHITE, true), lp(0, 10))
        checkLabels.forEach {
            val t = tv(it, 14f, muted)
            checks.add(t)
            prot.addView(t, lp(4, 4))
        }
        adminBtn = Button(this).apply {
            text = "Turn on uninstall protection"
            isAllCaps = false
            textSize = 14f
            setTextColor(Color.WHITE)
            background = round(Color.TRANSPARENT, 14, accent)
            stateListAnimator = null
            setOnClickListener { requestAdmin() }
        }
        prot.addView(adminBtn, LinearLayout.LayoutParams(MATCH, dp(48)).apply { setMargins(0, dp(12), 0, 0) })
        root.addView(prot, lp(0, 12))

        root.addView(
            tv(
                "A forced restart (holding Power + Volume Up for ~10 seconds) can't be blocked by any app. " +
                    "While a schedule is on, the date/time settings and this app's Settings pages stay blocked.",
                12f, muted
            ),
            lp()
        )

        setContentView(scroll)
        styleChips()
    }

    override fun onResume() { super.onResume(); handler.post(tick) }
    override fun onPause() { super.onPause(); handler.removeCallbacks(tick) }

    // ---------- chips ----------
    private fun styleChips() {
        val total = totalMinutes()
        chips.forEachIndexed { i, c ->
            val sel = presets[i].second == total
            c.background = round(if (sel) accent else chipOff, 14)
            c.setTextColor(if (sel) Color.WHITE else muted)
        }
    }

    private fun styleDays() {
        val mask = LockStore.scheduleDays(this)
        dayChips.forEachIndexed { i, c ->
            val sel = (mask and (1 shl dayCal[i])) != 0
            c.background = round(if (sel) accent else chipOff, 14)
            c.setTextColor(if (sel) Color.WHITE else muted)
        }
    }

    // ---------- state checks ----------
    private fun serviceEnabled(): Boolean {
        val enabled = Settings.Secure.getString(
            contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return enabled.contains("$packageName/") && enabled.contains("PowerBlockService")
    }

    private fun adminComponent() = ComponentName(this, AdminReceiver::class.java)

    private fun adminActive(): Boolean {
        val dpm = getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        return dpm.isAdminActive(adminComponent())
    }

    private fun requestAdmin() {
        startActivity(Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
            putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, adminComponent())
            putExtra(
                DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                "Stops Power Lock from being uninstalled while a lock or schedule is active."
            )
        })
    }

    // ---------- actions ----------
    private fun confirmStart() {
        val minutes = totalMinutes()
        if (minutes <= 0) {
            toast("Pick at least 1 minute")
            return
        }
        AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle("Start ${fmtDur(minutes)} lock?")
            .setMessage("This cannot be cancelled. Power off and restart will be blocked until it ends.")
            .setPositiveButton("Lock") { _, _ ->
                LockStore.startManual(this, minutes * 60_000L)
                refresh()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun scheduleLockedMsg() = toast("Schedule can't be changed while a lock is active")

    private fun onScheduleToggle(checked: Boolean) {
        if (updatingUi) return
        if (LockStore.isLocked(this)) {
            scheduleLockedMsg()
            refresh()
            return
        }
        val start = LockStore.scheduleStart(this)
        val end = LockStore.scheduleEnd(this)
        if (checked && start == end) {
            toast("Start and end time must be different")
            refresh()
            return
        }
        LockStore.setSchedule(this, checked, start, end, LockStore.scheduleDays(this))
        refresh()
    }

    private fun pickTime(isStart: Boolean) {
        if (LockStore.isLocked(this)) {
            scheduleLockedMsg()
            return
        }
        val current = if (isStart) LockStore.scheduleStart(this) else LockStore.scheduleEnd(this)
        TimePickerDialog(
            this,
            android.R.style.Theme_Material_Dialog,
            { _, h, m ->
                val value = h * 60 + m
                val s = if (isStart) value else LockStore.scheduleStart(this)
                val e = if (isStart) LockStore.scheduleEnd(this) else value
                if (LockStore.scheduleEnabled(this) && s == e) {
                    toast("Start and end time must be different")
                } else {
                    LockStore.setSchedule(this, LockStore.scheduleEnabled(this), s, e, LockStore.scheduleDays(this))
                }
                refresh()
            },
            current / 60,
            current % 60,
            false
        ).show()
    }

    private fun toggleDay(calDay: Int) {
        if (LockStore.isLocked(this)) {
            scheduleLockedMsg()
            return
        }
        val mask = LockStore.scheduleDays(this) xor (1 shl calDay)
        if (mask == 0) {
            toast("Keep at least one day selected")
            return
        }
        LockStore.setSchedule(
            this, LockStore.scheduleEnabled(this),
            LockStore.scheduleStart(this), LockStore.scheduleEnd(this), mask
        )
        refresh()
    }

    private fun scheduleText(): String {
        val mask = LockStore.scheduleDays(this)
        val picked = dayCal.indices.filter { (mask and (1 shl dayCal[it])) != 0 }
        val days = if (picked.size == 7) "every day" else picked.joinToString(", ") { dayNames[it] }
        return "Locks ${fmtTime(LockStore.scheduleStart(this))} to ${fmtTime(LockStore.scheduleEnd(this))}, $days"
    }

    // ---------- refresh ----------
    private fun refresh() {
        val st = LockStore.status(this)
        val locked = st.remainingMs > 0L
        val enabled = serviceEnabled()
        val admin = adminActive()
        val schedOn = LockStore.scheduleEnabled(this)
        val minutes = totalMinutes()

        when {
            locked -> {
                stateLabel.text = if (st.scheduled) "SCHEDULED LOCK" else "LOCKED"
                stateLabel.setTextColor(warn)
                timer.text = fmtClock(st.remainingMs)
                sub.text = "Power off & restart are blocked"
                progress.progress =
                    if (st.totalMs > 0) ((1.0 - st.remainingMs.toDouble() / st.totalMs) * 1000).toInt().coerceIn(0, 1000) else 0
            }
            !enabled -> {
                stateLabel.text = "SETUP NEEDED"
                stateLabel.setTextColor(warn)
                timer.text = "--:--:--"
                sub.text = "Enable the Accessibility service to begin"
                progress.progress = 0
            }
            else -> {
                stateLabel.text = "READY"
                stateLabel.setTextColor(good)
                timer.text = fmtClock(minutes * 60_000L)
                sub.text = if (schedOn) scheduleText() else "Pick a duration and start"
                progress.progress = 0
            }
        }

        startBtn.isEnabled = !locked && enabled && minutes > 0
        startBtn.alpha = if (startBtn.isEnabled) 1f else 0.4f
        accBtn.visibility = if (enabled) View.GONE else View.VISIBLE
        adminBtn.visibility = if (admin) View.GONE else View.VISIBLE

        val dim = if (locked) 0.4f else 1f
        durRow.alpha = dim
        hPick.alpha = dim
        mPick.alpha = dim
        hPick.isEnabled = !locked
        mPick.isEnabled = !locked

        updatingUi = true
        schedSwitch.isChecked = schedOn
        updatingUi = false
        fromBtn.text = "From  " + fmtTime(LockStore.scheduleStart(this))
        toBtn.text = "To  " + fmtTime(LockStore.scheduleEnd(this))
        schedSummary.text = if (schedOn) scheduleText() else "Schedule is off"
        schedSummary.setTextColor(if (schedOn) good else muted)
        val schedDim = if (locked) 0.5f else 1f
        fromBtn.alpha = schedDim
        toBtn.alpha = schedDim
        dayRow.alpha = schedDim
        styleDays()
        styleChips()

        checks.forEachIndexed { i, t ->
            val on = if (i == 5) admin else enabled
            t.text = (if (on) "✓  " else "○  ") + checkLabels[i]
            t.setTextColor(if (on) good else muted)
        }
    }
}
